import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div className="footer__brand">
          <div className="footer__logo">Regio-<span>Digital</span></div>
          <p className="footer__tagline">KI-gestützte Websites für lokale Unternehmen in der Region Stuttgart.</p>
        </div>
        <div className="footer__links">
          <h4>Leistungen</h4>
          <a href="#leistungen">Webdesign</a>
          <a href="#branchen">Branchen</a>
          <a href="#preise">Pakete & Preise</a>
          <a href="#kontakt">Kontakt</a>
        </div>
        <div className="footer__links">
          <h4>Rechtliches</h4>
          <a href="/impressum">Impressum</a>
          <a href="/datenschutz">Datenschutz</a>
        </div>
        <div className="footer__contact">
          <h4>Kontakt</h4>
          <a href="mailto:kontakt@regio-digital.de">kontakt@regio-digital.de</a>
          <span>+49 711 XXX XXXX</span>
          <span>Stuttgart, Baden-Württemberg</span>
        </div>
      </div>
      <div className="footer__bottom">
        <div className="container footer__bottom-inner">
          <span>© 2025 Regio-Digital Webdesign · Konstantin Valasis · Stuttgart</span>
          <span className="footer__made">Erstellt mit <span>Claude Code</span></span>
        </div>
      </div>
    </footer>
  )
}
