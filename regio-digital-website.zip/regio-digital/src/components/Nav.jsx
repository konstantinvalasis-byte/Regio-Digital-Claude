import { useState, useEffect } from 'react'
import { Menu, X } from 'lucide-react'
import './Nav.css'

const links = [
  { href: '#leistungen', label: 'Leistungen' },
  { href: '#branchen',   label: 'Branchen' },
  { href: '#ablauf',     label: 'Ablauf' },
  { href: '#preise',     label: 'Preise' },
  { href: '#kontakt',    label: 'Kontakt' },
]

export default function Nav() {
  const [open, setOpen]       = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const close = () => setOpen(false)

  return (
    <header className={`nav${scrolled ? ' nav--scrolled' : ''}`}>
      <div className="container nav__inner">
        <a href="#" className="nav__logo" onClick={close}>
          Regio-<span>Digital</span>
        </a>

        <nav className={`nav__links${open ? ' nav__links--open' : ''}`}>
          {links.map((l) => (
            <a key={l.href} href={l.href} className="nav__link" onClick={close}>
              {l.label}
            </a>
          ))}
          <a href="#kontakt" className="btn btn-primary nav__cta" onClick={close}>
            Demo anfragen
          </a>
        </nav>

        <button
          className="nav__burger"
          onClick={() => setOpen(!open)}
          aria-label={open ? 'Menü schließen' : 'Menü öffnen'}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
    </header>
  )
}
