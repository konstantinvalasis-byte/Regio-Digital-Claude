import { useScrollReveal } from './hooks/useScrollReveal'
import Nav        from './components/Nav'
import Footer     from './components/Footer'
import Hero       from './sections/Hero'
import Problems   from './sections/Problems'
import Branchen   from './sections/Branchen'
import Ablauf     from './sections/Ablauf'
import Preise     from './sections/Preise'
import Demos      from './sections/Demos'
import UeberMich  from './sections/UeberMich'
import FAQ        from './sections/FAQ'
import Kontakt    from './sections/Kontakt'

export default function App() {
  useScrollReveal()

  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Problems />
        <Branchen />
        <Ablauf />
        <Preise />
        <Demos />
        <UeberMich />
        <FAQ />
        <Kontakt />
      </main>
      <Footer />
    </>
  )
}
