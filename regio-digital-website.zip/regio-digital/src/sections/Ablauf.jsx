import './Ablauf.css'

const steps = [
  { day: 'Tag 1',   title: 'Gespräch & Briefing',  text: '30 Minuten. Ich lerne Ihr Unternehmen kennen. Was soll die Website leisten? Welche Kunden sollen sie finden?' },
  { day: 'Tag 2–3', title: 'Entwicklung',           text: 'Claude Code erstellt die komplette Website. Branchenspezifischer Code, saubere Struktur, schnelle Ladezeiten.' },
  { day: 'Tag 4–5', title: 'Ihr Feedback',          text: 'Sie sehen die erste Version. Eine Korrekturschleife inklusive. Änderungswünsche werden umgehend umgesetzt.' },
  { day: 'Tag 6–7', title: 'Live-Schaltung',        text: 'Domain, Hosting, SSL, Impressum, Datenschutz – alles fertig. Ihre Website ist online. DSGVO-konform. Server in Deutschland.' },
]

export default function Ablauf() {
  return (
    <section className="ablauf" id="ablauf">
      <div className="container">
        <div className="ablauf__header reveal">
          <span className="section-label">Der Prozess</span>
          <h2 className="section-title">Von der Idee zur fertigen Website –<br />in 7 Tagen</h2>
        </div>
        <div className="ablauf__steps">
          {steps.map(({ day, title, text }, i) => (
            <div key={day} className={`ablauf__step reveal reveal-delay-${i + 1}`}>
              <div className="ablauf__step-left">
                <div className="ablauf__day">{day}</div>
                <div className="ablauf__connector" />
              </div>
              <div className="ablauf__step-right">
                <h3 className="ablauf__title">{title}</h3>
                <p className="ablauf__text">{text}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="ablauf__cta reveal">
          <p>Bereit? Ich zeige Ihnen vorab, wie Ihre Website aussehen könnte.</p>
          <a href="#kontakt" className="btn btn-primary">Kostenlose Demo anfordern</a>
        </div>
      </div>
    </section>
  )
}
