import { useState } from 'react'
import { Mail, Phone, MapPin, Clock } from 'lucide-react'
import './Kontakt.css'

export default function Kontakt() {
  const [sent, setSent] = useState(false)
  const [form, setForm] = useState({ name: '', firma: '', branche: '', email: '', telefon: '', nachricht: '' })

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = (e) => {
    e.preventDefault()
    // Replace with your Formspree endpoint: https://formspree.io/f/YOUR_ID
    setSent(true)
  }

  return (
    <section className="kontakt" id="kontakt">
      <div className="container">
        <div className="kontakt__header reveal">
          <span className="section-label" style={{ color: 'var(--accent)' }}>Kontakt</span>
          <h2 className="section-title light">Lassen Sie uns sprechen.</h2>
          <p className="section-sub light">
            Ich zeige Ihnen kostenlos, wie eine Website für Ihr Unternehmen aussehen könnte –
            bevor Sie sich für irgendetwas entscheiden.
          </p>
        </div>

        <div className="kontakt__inner">
          <div className="kontakt__form-wrap reveal">
            {sent ? (
              <div className="kontakt__success">
                <div className="kontakt__success-icon">✓</div>
                <h3>Nachricht erhalten!</h3>
                <p>Ich melde mich innerhalb von 24 Stunden bei Ihnen.</p>
              </div>
            ) : (
              <form className="kontakt__form" onSubmit={handleSubmit}>
                <div className="kontakt__row">
                  <div className="kontakt__field">
                    <label htmlFor="name">Name *</label>
                    <input id="name" name="name" type="text" required value={form.name} onChange={handleChange} placeholder="Max Mustermann" />
                  </div>
                  <div className="kontakt__field">
                    <label htmlFor="firma">Unternehmen</label>
                    <input id="firma" name="firma" type="text" value={form.firma} onChange={handleChange} placeholder="Muster GmbH" />
                  </div>
                </div>
                <div className="kontakt__field">
                  <label htmlFor="branche">Branche</label>
                  <select id="branche" name="branche" value={form.branche} onChange={handleChange}>
                    <option value="">Bitte wählen…</option>
                    <option value="handwerk">Handwerk</option>
                    <option value="arztpraxis">Arztpraxis</option>
                    <option value="gastronomie">Gastronomie</option>
                    <option value="beauty">Beauty &amp; Wellness</option>
                    <option value="sonstiges">Sonstiges</option>
                  </select>
                </div>
                <div className="kontakt__row">
                  <div className="kontakt__field">
                    <label htmlFor="email">E-Mail *</label>
                    <input id="email" name="email" type="email" required value={form.email} onChange={handleChange} placeholder="info@ihr-unternehmen.de" />
                  </div>
                  <div className="kontakt__field">
                    <label htmlFor="telefon">Telefon</label>
                    <input id="telefon" name="telefon" type="tel" value={form.telefon} onChange={handleChange} placeholder="+49 711 …" />
                  </div>
                </div>
                <div className="kontakt__field">
                  <label htmlFor="nachricht">Nachricht</label>
                  <textarea id="nachricht" name="nachricht" rows={4} value={form.nachricht} onChange={handleChange} placeholder="Was darf ich für Sie tun?" />
                </div>
                <button type="submit" className="btn btn-primary kontakt__submit">
                  Nachricht senden
                </button>
              </form>
            )}
          </div>

          <div className="kontakt__info reveal reveal-delay-2">
            <div className="kontakt__info-item">
              <Mail size={18} />
              <div>
                <div className="kontakt__info-label">E-Mail</div>
                <a href="mailto:kontakt@regio-digital.de">kontakt@regio-digital.de</a>
              </div>
            </div>
            <div className="kontakt__info-item">
              <Phone size={18} />
              <div>
                <div className="kontakt__info-label">Telefon</div>
                <a href="tel:+4971100000">+49 711 XXX XXXX</a>
              </div>
            </div>
            <div className="kontakt__info-item">
              <MapPin size={18} />
              <div>
                <div className="kontakt__info-label">Standort</div>
                <span>Stuttgart, Baden-Württemberg</span>
              </div>
            </div>
            <div className="kontakt__info-item">
              <Clock size={18} />
              <div>
                <div className="kontakt__info-label">Reaktionszeit</div>
                <span>Innerhalb von 24 Stunden</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
