import { Check } from 'lucide-react'
import './Preise.css'

const pakete = [
  {
    name: 'Starter',
    price: '590',
    sub: 'Die digitale Visitenkarte',
    features: ['One-Pager (mobil-optimiert)', 'SSL + Impressum + Datenschutz', 'Kontaktformular', 'Google Maps Einbindung', 'SEO-Grundstruktur', 'Lieferung in 5 Tagen'],
    highlight: false,
  },
  {
    name: 'Business',
    price: '990',
    sub: 'Der Kunden-Magnet',
    badge: 'Meistgewählt',
    features: ['3–5 Seiten', 'Alles aus Starter', 'Erweitertes SEO', 'Google Business Setup', 'Terminbuchung (opt. +150 €)', 'Lieferung in 7 Tagen'],
    highlight: true,
  },
  {
    name: 'Premium',
    price: '1.590',
    sub: 'Der lokale Marktführer',
    features: ['6+ Seiten', 'Alles aus Business', 'Vollständiges SEO-Paket', 'Google Business Optimierung', 'Content-Strategie', 'Lieferung in 10–14 Tagen'],
    highlight: false,
  },
]

const hosting = [
  {
    name: 'Basic',
    price: '29',
    features: ['Premium-Hosting DE (netcup)', 'SSL-Zertifikat + Auto-Renewal', 'Tägliche Backups (30 Tage)', 'Rechtstexte-Updates (eRecht24)', 'Sicherheits-Updates wöchentlich', '1× Inhaltspflege pro Monat', 'Reaktionszeit: 3 Werktage'],
  },
  {
    name: 'Pro',
    price: '49',
    features: ['Alles aus Basic', 'Tägliche Sicherheits-Updates', 'Unbegrenzte Inhaltspflege', 'Monatlicher Performance-Report', 'Reaktionszeit: 24 Stunden', 'Prioritäts-Support'],
  },
]

export default function Preise() {
  return (
    <section className="preise" id="preise">
      <div className="container">
        <div className="preise__header reveal">
          <span className="section-label">Pakete & Preise</span>
          <h2 className="section-title">Transparente Festpreise.<br />Keine versteckten Kosten.</h2>
        </div>

        <div className="preise__grid">
          {pakete.map(({ name, price, sub, badge, features, highlight }) => (
            <div key={name} className={`preise__card${highlight ? ' preise__card--highlight' : ''}`}>
              {badge && <div className="preise__badge">{badge}</div>}
              <div className="preise__card-header">
                <h3 className="preise__name">{name}</h3>
                <p className="preise__sub">{sub}</p>
              </div>
              <div className="preise__price">
                <span className="preise__amount">{price} €</span>
                <span className="preise__once">einmalig</span>
              </div>
              <ul className="preise__features">
                {features.map(f => (
                  <li key={f}>
                    <Check size={15} strokeWidth={2.5} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <a href="#kontakt" className={`btn ${highlight ? 'btn-primary' : 'btn-ghost'} preise__btn`}>
                Jetzt anfragen
              </a>
            </div>
          ))}
        </div>

        <div className="preise__hosting reveal">
          <div className="preise__hosting-header">
            <span className="section-label">Digitaler Hausmeister</span>
            <h3 className="preise__hosting-title">ab 29 €/Monat</h3>
            <p className="preise__hosting-sub">
              Jede Website läuft mit einem Pflege-Paket. Hosting in Deutschland,
              tägliche Backups, Sicherheits-Updates, Rechtstexte automatisch aktuell.
            </p>
          </div>
          <div className="preise__hosting-grid">
            {hosting.map(({ name, price, features }) => (
              <div key={name} className="preise__hosting-card">
                <div className="preise__hosting-name">{name}</div>
                <div className="preise__hosting-price">{price} €<span>/Mo</span></div>
                <ul className="preise__features preise__features--small">
                  {features.map(f => (
                    <li key={f}>
                      <Check size={13} strokeWidth={2.5} />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
