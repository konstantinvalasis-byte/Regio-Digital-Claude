import { Smartphone, Clock, AlertTriangle } from 'lucide-react'
import './Problems.css'

const problems = [
  {
    icon: Smartphone,
    heading: 'Ihre Website läuft noch auf Internet Explorer…',
    stat: 'Über 60 % der KMU-Websites in Deutschland sind nicht mobil-optimiert. Potenzielle Kunden springen ab, bevor sie gelesen haben, was Sie anbieten.',
  },
  {
    icon: Clock,
    heading: 'Die letzte Änderung hat 3 Wochen gedauert…',
    stat: 'Klassische Agenturen: 4–8 Wochen Wartezeit, 3.000–15.000 € Kosten. Für viele KMU schlicht nicht tragbar.',
  },
  {
    icon: AlertTriangle,
    heading: 'DSGVO? Impressum? Da bin ich unsicher…',
    stat: 'Fehlende oder veraltete Rechtstexte sind eine der häufigsten Abmahn-Fallen für Gewerbetreibende in Deutschland.',
  },
]

export default function Problems() {
  return (
    <section className="problems" id="leistungen">
      <div className="container">
        <div className="problems__header reveal">
          <span className="section-label">Das Problem</span>
          <h2 className="section-title">Kennen Sie das?</h2>
        </div>
        <div className="problems__grid">
          {problems.map(({ icon: Icon, heading, stat }, i) => (
            <div key={heading} className={`problems__card reveal reveal-delay-${i + 1}`}>
              <div className="problems__icon">
                <Icon size={22} strokeWidth={2} />
              </div>
              <h3 className="problems__heading">{heading}</h3>
              <p className="problems__text">{stat}</p>
            </div>
          ))}
        </div>
        <p className="problems__cta-text reveal">
          Genau dafür gibt es <strong>Regio-Digital.</strong>
        </p>
      </div>
    </section>
  )
}
