import './Demos.css'

function BrowserFrame({ url, children }) {
  return (
    <div className="demo-browser">
      <div className="demo-chrome">
        <span className="demo-dot demo-dot--r" />
        <span className="demo-dot demo-dot--y" />
        <span className="demo-dot demo-dot--g" />
        <div className="demo-url">{url}</div>
      </div>
      <div className="demo-screen">{children}</div>
    </div>
  )
}

function HandwerkMockup() {
  return (
    <BrowserFrame url="wagner-elektrotechnik-stuttgart.de">
      <div className="hw">
        <div className="hw__ticker">📞 NOTFALL: +49 711 000 000 — 24/7 ERREICHBAR</div>
        <div className="hw__nav">
          <div className="hw__logo">WAGNER<span>ELEKTRO</span></div>
          <div className="hw__nav-links">
            <div className="hw__link" /><div className="hw__link" /><div className="hw__link" />
          </div>
        </div>
        <div className="hw__hero">
          <div className="hw__bolt">⚡</div>
          <div className="hw__content">
            <div className="hw__tag">ELEKTRIKER · STUTTGART</div>
            <div className="hw__h1">IHR ELEKTRIKER<br />IN STUTTGART.</div>
            <div className="hw__sub">Notdienst · Neuinstallation · Smart Home</div>
            <div className="hw__btns">
              <div className="hw__btn hw__btn--fill">JETZT ANRUFEN</div>
              <div className="hw__btn hw__btn--out">Referenzen</div>
            </div>
          </div>
        </div>
        <div className="hw__badges">
          <div className="hw__badge">⚡ Blitzschnell</div>
          <div className="hw__badge">✓ Meisterbetrieb</div>
          <div className="hw__badge">★ 4.9 Google</div>
        </div>
      </div>
    </BrowserFrame>
  )
}

function ArztMockup() {
  return (
    <BrowserFrame url="praxis-dr-mueller-stuttgart.de">
      <div className="arzt">
        <div className="arzt__nav">
          <div className="arzt__logo">Dr. med. Müller</div>
          <div className="arzt__nav-r">
            <div className="arzt__link" /><div className="arzt__link" /><div className="arzt__link" />
            <div className="arzt__book">Termin buchen</div>
          </div>
        </div>
        <div className="arzt__hero">
          <div className="arzt__left">
            <div className="arzt__tag">ALLGEMEINMEDIZIN · STUTTGART-MITTE</div>
            <div className="arzt__h1">Ihre Gesundheit.<br />Unser Einsatz.</div>
            <div className="arzt__sub">Persönliche Betreuung, kurze Wartezeiten, Online-Terminbuchung.</div>
            <div className="arzt__btn">Termin vereinbaren</div>
            <div className="arzt__trust">
              <div className="arzt__trust-item">🕐 Mo–Fr 8–18 Uhr</div>
              <div className="arzt__trust-item">📋 Alle Kassen</div>
              <div className="arzt__trust-item">🌐 Online-Termine</div>
            </div>
          </div>
          <div className="arzt__right">
            <div className="arzt__circle">
              <svg viewBox="0 0 48 48" fill="none" width="36" height="36">
                <circle cx="24" cy="16" r="8" stroke="white" strokeWidth="2.5"/>
                <path d="M20 20v5h-4v4h4v5h8v-5h4v-4h-4v-5h-8z" fill="white" opacity=".8"/>
              </svg>
            </div>
            <div className="arzt__card">
              <span className="arzt__dot" />
              <span>Nächster Termin: Morgen, 10:30</span>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  )
}

function GastroMockup() {
  return (
    <BrowserFrame url="trattoria-bellavista-stuttgart.de">
      <div className="gastro">
        <div className="gastro__nav">
          <div className="gastro__logo">Trattoria Bella Vista</div>
          <div className="gastro__links">
            <div className="gastro__link" /><div className="gastro__link" /><div className="gastro__link" />
          </div>
        </div>
        <div className="gastro__hero">
          <div className="gastro__emblem">✦</div>
          <div className="gastro__divider" />
          <div className="gastro__h1">Trattoria<br />Bella Vista</div>
          <div className="gastro__divider" />
          <div className="gastro__tag">CUCINA ITALIANA · STUTTGART-WEST · SEIT 1998</div>
          <div className="gastro__btns">
            <div className="gastro__btn gastro__btn--out">Tisch reservieren</div>
            <div className="gastro__btn gastro__btn--fill">Speisekarte</div>
          </div>
        </div>
        <div className="gastro__footer">
          <div className="gastro__fi">📍 Rotebühlplatz 12</div>
          <div className="gastro__fi">🕐 Di–So 12–23 Uhr</div>
          <div className="gastro__fi">☎ Reservierung</div>
        </div>
      </div>
    </BrowserFrame>
  )
}

function BeautyMockup() {
  return (
    <BrowserFrame url="studio-lumiere-stuttgart.de">
      <div className="beauty">
        <div className="beauty__nav">
          <div className="beauty__logo">STUDIO LUMIÈRE</div>
          <div className="beauty__book">TERMIN BUCHEN</div>
        </div>
        <div className="beauty__hero">
          <div className="beauty__accent-line" />
          <div className="beauty__vertical">BEAUTY · NAILS · WELLNESS</div>
          <div className="beauty__content">
            <div className="beauty__star">✦</div>
            <div className="beauty__h1">Schönheit<br />neu definiert.</div>
            <div className="beauty__divider" />
            <div className="beauty__sub">Premium Nageldesign · Kosmetik · Wimpern<br />Stuttgart-Mitte · Nur nach Vereinbarung</div>
            <div className="beauty__btn">TERMIN VEREINBAREN</div>
          </div>
          <div className="beauty__deco">
            <div className="beauty__ring" />
            <div className="beauty__flower">✿</div>
          </div>
        </div>
        <div className="beauty__strip">
          ✦ Nageldesign ✦ Kosmetik ✦ Wimpern & Brauen ✦ Massagen ✦
        </div>
      </div>
    </BrowserFrame>
  )
}

const demos = [
  { label: 'Handwerk',       color: '#C8922A', bg: '#FDF8F0', Component: HandwerkMockup },
  { label: 'Arztpraxis',     color: '#2D7A4F', bg: '#F0F8F4', Component: ArztMockup    },
  { label: 'Gastronomie',    color: '#C0392B', bg: '#FDF2F1', Component: GastroMockup  },
  { label: 'Beauty & Wellness', color: '#7B4DA8', bg: '#F6F0FC', Component: BeautyMockup },
]

export default function Demos() {
  return (
    <section className="demos" id="demos">
      <div className="container">
        <div className="demos__header reveal">
          <span className="section-label">Referenz-Konzepte</span>
          <h2 className="section-title">So könnte Ihre Website aussehen</h2>
          <p className="section-sub">Vier Branchen. Vier Konzepte. Jedes maßgeschneidert – kein Template, kein Einheitsbrei.</p>
        </div>
        <div className="demos__grid">
          {demos.map(({ label, color, bg, Component }, i) => (
            <div key={label} className={`demos__item reveal reveal-delay-${(i % 2) + 1}`}>
              <div className="demos__label" style={{ background: color }}>
                {label}
              </div>
              <div className="demos__frame-wrap" style={{ '--demo-bg': bg }}>
                <Component />
                <div className="demos__overlay">
                  <span>Konzept ansehen →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
