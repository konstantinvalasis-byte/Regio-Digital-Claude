import { ShieldCheck, Zap, MapPin, Tag } from 'lucide-react'
import './Hero.css'

const trust = [
  { icon: ShieldCheck, label: 'DSGVO-konform' },
  { icon: MapPin,      label: 'Server in Deutschland' },
  { icon: Tag,         label: 'Festpreise' },
  { icon: Zap,         label: '7-Tage-Lieferung' },
]

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero__bg-pattern" aria-hidden="true" />
      <div className="container hero__inner">
        <div className="hero__text">
          <span className="section-label">Webdesign Stuttgart</span>
          <h1 className="hero__headline">
            Ihre Website.<br />
            In 7 Tagen.<br />
            <em>Zum Festpreis.</em>
          </h1>
          <p className="hero__sub">
            Ich erstelle KI-gestützte, rechtssichere Websites für Handwerker,
            Arztpraxen, Restaurants und Beautystudios in der Region Stuttgart –
            schneller und günstiger als jede Agentur.
          </p>
          <div className="hero__ctas">
            <a href="#kontakt" className="btn btn-primary">Demo kostenlos ansehen</a>
            <a href="#preise"  className="btn btn-ghost">Pakete &amp; Preise</a>
          </div>
          <div className="hero__trust">
            {trust.map(({ icon: Icon, label }) => (
              <div key={label} className="hero__trust-item">
                <Icon size={15} strokeWidth={2.2} />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="hero__mockup" aria-hidden="true">
          <div className="browser">
            <div className="browser__chrome">
              <span className="dot dot--red" />
              <span className="dot dot--yellow" />
              <span className="dot dot--green" />
              <div className="browser__url">regio-digital.de</div>
            </div>
            <div className="browser__screen">
              <div className="bm__nav">
                <div className="bm__logo-bar" />
                <div className="bm__nav-links">
                  <div className="bm__line bm__line--sm" />
                  <div className="bm__line bm__line--sm" />
                  <div className="bm__line bm__line--sm" />
                  <div className="bm__btn-pill" />
                </div>
              </div>
              <div className="bm__hero">
                <div className="bm__hero-text">
                  <div className="bm__line bm__line--xl" />
                  <div className="bm__line bm__line--lg" />
                  <div className="bm__line bm__line--md" />
                  <div className="bm__line bm__line--md bm__line--short" />
                  <div className="bm__ctas">
                    <div className="bm__cta bm__cta--filled" />
                    <div className="bm__cta bm__cta--outline" />
                  </div>
                </div>
                <div className="bm__hero-visual">
                  <div className="bm__circle-outer">
                    <div className="bm__circle-inner" />
                    <svg className="bm__icon" viewBox="0 0 40 40" fill="none">
                      <rect x="8" y="6" width="24" height="28" rx="3" stroke="currentColor" strokeWidth="2.5" fill="none"/>
                      <path d="M14 14h12M14 19h12M14 24h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                  </div>
                  <div className="bm__floating-card">
                    <div className="bm__card-dot" />
                    <div className="bm__card-text">
                      <div className="bm__line bm__line--xs" />
                      <div className="bm__line bm__line--xs bm__line--short" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="bm__trust-row">
                {[1,2,3,4].map(i => (
                  <div key={i} className="bm__trust-badge">
                    <div className="bm__badge-icon" />
                    <div className="bm__line bm__line--xs" />
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="hero__mockup-shadow" />
        </div>
      </div>
    </section>
  )
}
