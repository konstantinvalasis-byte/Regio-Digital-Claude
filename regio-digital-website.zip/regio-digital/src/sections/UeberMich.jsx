import { MapPin, Zap, ShieldCheck } from 'lucide-react'
import './UeberMich.css'

export default function UeberMich() {
  return (
    <section className="ueber" id="ueber">
      <div className="container ueber__inner">
        <div className="ueber__visual reveal">
          <div className="ueber__avatar">KV</div>
          <div className="ueber__avatar-ring" />
        </div>
        <div className="ueber__text reveal reveal-delay-1">
          <span className="section-label">Über mich</span>
          <h2 className="section-title">Hallo, ich bin Konstantin.</h2>
          <p className="ueber__p">
            Ich bin kein Konzern und keine anonyme Agentur. Ich bin ein einzelner Entwickler
            aus Stuttgart, der KI-Tools so einsetzt, dass lokale Unternehmen endlich die Website
            bekommen, die sie verdienen – ohne Agentur-Budget.
          </p>
          <p className="ueber__p">
            Was das für Sie bedeutet: Ein fester Ansprechpartner, direkte Kommunikation,
            keine Weiterleitungen. Ich kenne Ihre Website, weil ich sie gebaut habe.
          </p>
          <div className="ueber__facts">
            <div className="ueber__fact">
              <MapPin size={15} />
              <span>Stuttgart</span>
            </div>
            <div className="ueber__fact">
              <Zap size={15} />
              <span>7 Tage Lieferung</span>
            </div>
            <div className="ueber__fact">
              <ShieldCheck size={15} />
              <span>DSGVO-konform</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
