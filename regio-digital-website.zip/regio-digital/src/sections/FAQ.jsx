import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import './FAQ.css'

const faqs = [
  {
    q: 'Warum sind Ihre Preise günstiger als bei einer Agentur?',
    a: 'Ich arbeite solo und nutze KI-gestützte Entwicklungstools, die mir erlauben, in einem Bruchteil der Zeit professionelle Ergebnisse zu liefern. Keine Agentur-Overheads, keine langen Kommunikationsketten – der Vorteil landet direkt bei Ihnen.',
  },
  {
    q: 'Was bedeutet „DSGVO-konform"?',
    a: 'Ihre Website wird auf einem Server in Deutschland gehostet (netcup, Karlsruhe). Impressum und Datenschutzerklärung werden über eRecht24 automatisch aktuell gehalten. Sie müssen sich um nichts kümmern.',
  },
  {
    q: 'Was passiert nach der Lieferung?',
    a: 'Mit dem Digitaler-Hausmeister-Abo (ab 29 €/Mo) kümmere ich mich dauerhaft um Hosting, Updates, Backups und kleine Inhaltsänderungen. Sie können sich voll auf Ihr Geschäft konzentrieren.',
  },
  {
    q: 'Kann ich meine Website später selbst bearbeiten?',
    a: 'Ja. Je nach Paket richte ich Ihnen ein einfaches CMS ein, mit dem Sie Texte und Bilder selbst ändern können – ohne Programmierkenntnisse.',
  },
  {
    q: 'Wie läuft die Bezahlung ab?',
    a: '50 % bei Auftragserteilung, 50 % bei Live-Schaltung. Keine Monatsgebühren für die Erstellung – nur das Hosting-Abo läuft monatlich.',
  },
]

function FAQItem({ q, a }) {
  const [open, setOpen] = useState(false)
  return (
    <div className={`faq__item${open ? ' faq__item--open' : ''}`}>
      <button className="faq__q" onClick={() => setOpen(!open)} aria-expanded={open}>
        <span>{q}</span>
        <ChevronDown size={18} className="faq__icon" />
      </button>
      <div className="faq__a" style={{ maxHeight: open ? '200px' : '0' }}>
        <p>{a}</p>
      </div>
    </div>
  )
}

export default function FAQ() {
  return (
    <section className="faq" id="faq">
      <div className="container">
        <div className="faq__header reveal">
          <span className="section-label">FAQ</span>
          <h2 className="section-title">Häufige Fragen</h2>
        </div>
        <div className="faq__list">
          {faqs.map((item, i) => (
            <div key={i} className="reveal reveal-delay-1">
              <FAQItem {...item} />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
