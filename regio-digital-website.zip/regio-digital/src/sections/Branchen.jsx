import './Branchen.css'

const branchen = [
  {
    emoji: '🔨',
    title: 'Handwerk',
    sub: 'Elektriker, Maler, Dachdecker & Co.',
    color: '#C8922A',
    bg: 'rgba(200,146,42,0.08)',
    hook: 'Wenn jemand um 22 Uhr einen Rohrbruch hat, findet er SIE bei Google – nicht die Konkurrenz.',
    features: ['Notfall-Kontakt prominent', 'Referenzgalerie', 'Google Maps Integration', 'Bewertungen einbinden'],
  },
  {
    emoji: '🏥',
    title: 'Arztpraxen',
    sub: 'Allgemeinärzte, Zahnärzte, Physiotherapeuten',
    color: '#2D7A4F',
    bg: 'rgba(45,122,79,0.08)',
    hook: 'Patienten buchen heute online. Wer das nicht anbietet, verliert sie an die Praxis nebenan.',
    features: ['Online-Terminbuchung', 'Leistungsübersicht', 'Team-Vorstellung', 'Vertrauenswürdiges Design'],
  },
  {
    emoji: '🍽️',
    title: 'Gastronomie',
    sub: 'Restaurants, Cafés, Imbisse, Catering',
    color: '#C0392B',
    bg: 'rgba(192,57,43,0.08)',
    hook: 'Bevor Gäste kommen, entscheiden sie online. Ihre Website ist der erste Eindruck – noch vor dem Essen.',
    features: ['Digitale Speisekarte', 'Tischreservierung', 'Atmosphären-Fotos', 'Öffnungszeiten prominent'],
  },
  {
    emoji: '💅',
    title: 'Beauty & Wellness',
    sub: 'Friseure, Nagelstudios, Kosmetikstudios',
    color: '#7B4DA8',
    bg: 'rgba(123,77,168,0.08)',
    hook: 'Ihre Arbeit ist visuell. Ihre Website muss das zeigen – mit einem Portfolio, das begeistert.',
    features: ['Online-Terminbuchung', 'Vorher-Nachher-Galerie', 'Preisliste', 'Instagram-würdige Optik'],
  },
]

export default function Branchen() {
  return (
    <section className="branchen" id="branchen">
      <div className="container">
        <div className="branchen__header reveal">
          <span className="section-label">Zielgruppen</span>
          <h2 className="section-title light">Für Ihre Branche gemacht</h2>
          <p className="section-sub light">Jede Branche braucht andere Inhalte. Ich kenne die Unterschiede.</p>
        </div>
        <div className="branchen__grid">
          {branchen.map(({ emoji, title, sub, color, bg, hook, features }, i) => (
            <div
              key={title}
              className={`branchen__card reveal reveal-delay-${(i % 2) + 1}`}
              style={{ '--card-color': color, '--card-bg': bg }}
            >
              <div className="branchen__card-top">
                <span className="branchen__emoji">{emoji}</span>
                <div>
                  <h3 className="branchen__title">{title}</h3>
                  <p className="branchen__sub">{sub}</p>
                </div>
              </div>
              <p className="branchen__hook">„{hook}"</p>
              <ul className="branchen__features">
                {features.map(f => (
                  <li key={f}>
                    <span className="branchen__check">✓</span>
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
